package com.star.usercenter.constant;

/**
 *
 *  user constant
 *
 */



public interface UserContent {

    String USER_LOGIN_STATE = "userLoginState";

    int DEFAULT_ROLE = 0;
    int ADMIN_ROLE = 1;

}
