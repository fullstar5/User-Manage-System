package com.star.usercenter.mapper;

import com.star.usercenter.model.domain.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author Administrator
* @description 针对表【user(user_table)】的数据库操作Mapper
* @createDate 2023-04-26 01:18:29
* @Entity generator.domain.User
*/
public interface UserMapper extends BaseMapper<User> {

}




